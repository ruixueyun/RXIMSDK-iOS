//
//  RXIMMsgTextContent.h
//  RXIMSdk
//
//  Created by 陈汉 on 2021/9/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RXIMMsgTextContent : NSObject

/** 内容 */
@property(nonatomic, copy) NSString *text;

@end

NS_ASSUME_NONNULL_END
